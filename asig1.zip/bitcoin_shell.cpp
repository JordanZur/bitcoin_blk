#include "programs.h"

int main(){
    int choice;
    while (true)
    {
    std::cout<<"\n === Bitcoin Shell Menu===\n";
    std::cout<<"1. Print db\n";
    std::cout<<"2. print block by hash\n";
    std::cout<<"3. print block by height\n";
    std::cout<<"4. Export data to csv\n";
    std::cout<<"5. Refreash data\n";
   
    std::cout<<"Enter your choice:";
    std::cin >> choice;
    std::string hash;
    std::string height;
    
    switch (choice)
    {
    case 1:
    printChainFromFile("blocks.dat");
        break;
    case 2:
    std::cout<<"Enter block hash:";
    std::cin>>hash;
    findBlockByField("hash", "blocks.dat",hash);
        break;
    case 3: 
    std::cout<<"Enter block height:";
    std::cin>>height;
    findBlockByField("height", "blocks.dat",height);


    case 0 :
    return 0;

        break;
    }
}

    return 0;
    
}
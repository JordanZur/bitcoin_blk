#pragma once
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

struct Block {
    std::string hash;
    std::string height;
    std::string total;
    std::string time;
    std::string received_time;
    std::string relayed_by;
    std::string prev_block;
};

void printBlock(const Block& block);
void printChainFromFile(const std::string& file_name);
void findBlockByField(const std::string& field, const std::string& filename, const std::string& value);